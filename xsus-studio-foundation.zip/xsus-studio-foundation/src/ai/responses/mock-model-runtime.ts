import type { ModelRuntime } from "../core/types";

/**
 * Development placeholder only. This is NOT a real language model.
 * Replace with a local model server or an approved hosted provider adapter.
 */
export class MockModelRuntime implements ModelRuntime {
  async generate(input: Parameters<ModelRuntime["generate"]>[0]): Promise<string> {
    const question = input.messages.at(-1)?.content ?? "";
    const knowledgeText = input.knowledge.map((item) => item.content).join("\n\n");

    if (knowledgeText) {
      return `Përgjigje prove (model demonstrues):\n\n${knowledgeText}\n\nPyetja jote: ${question}`;
    }

    return `XSUS AI është në fazën e konfigurimit. Ende nuk është lidhur me një model real. Pyetja jote: ${question}`;
  }
}
