import type {
  ChatRequest,
  ChatResponse,
  LanguageEngine,
  KnowledgeRetriever,
  ModelRuntime,
  SupportedLanguage,
} from "./types";

export interface OrchestratorDependencies {
  language: LanguageEngine;
  knowledge: KnowledgeRetriever;
  model: ModelRuntime;
}

export class AIOrchestrator {
  constructor(private readonly deps: OrchestratorDependencies) {}

  async answer(request: ChatRequest): Promise<ChatResponse> {
    const message = request.message.trim();

    if (!message) {
      throw new Error("Mesazhi nuk mund të jetë bosh.");
    }

    const language: SupportedLanguage =
      request.language && request.language !== "unknown"
        ? request.language
        : this.deps.language.detect(message);

    const knowledge = await this.deps.knowledge.search(message, language);
    const answer = await this.deps.model.generate({
      messages: [{ role: "user", content: message }],
      language,
      knowledge,
    });

    return {
      conversationId: request.conversationId ?? crypto.randomUUID(),
      answer,
      language,
      sources: knowledge.map((item) => ({
        id: item.id,
        title: item.title,
        source: item.source,
      })),
      mode: "model",
    };
  }
}
