export type SupportedLanguage = "sq" | "en" | "fr" | "de" | "it" | "unknown";

export interface ChatMessage {
  role: "system" | "user" | "assistant";
  content: string;
}

export interface ChatRequest {
  conversationId?: string;
  userId?: string;
  message: string;
  language?: SupportedLanguage;
}

export interface KnowledgeItem {
  id: string;
  title: string;
  content: string;
  language: SupportedLanguage;
  source?: string;
}

export interface ChatResponse {
  conversationId: string;
  answer: string;
  language: SupportedLanguage;
  sources: Array<{ id: string; title: string; source?: string }>;
  mode: "mock" | "model";
}

export interface LanguageEngine {
  detect(text: string): SupportedLanguage;
}

export interface KnowledgeRetriever {
  search(query: string, language: SupportedLanguage): Promise<KnowledgeItem[]>;
}

export interface ModelRuntime {
  generate(input: {
    messages: ChatMessage[];
    language: SupportedLanguage;
    knowledge: KnowledgeItem[];
  }): Promise<string>;
}
