import type { LanguageEngine, SupportedLanguage } from "../core/types";

/**
 * A tiny placeholder detector for scaffolding only.
 * Replace with a tested language-identification library/model.
 */
export class BasicLanguageEngine implements LanguageEngine {
  detect(text: string): SupportedLanguage {
    const normalized = text.toLocaleLowerCase();

    if (/[ëç]/i.test(normalized) || /\b(përshëndetje|është|çfarë|si|faleminderit)\b/i.test(normalized)) {
      return "sq";
    }

    if (/\b(hello|what|how|thanks|please)\b/i.test(normalized)) return "en";
    if (/\b(bonjour|merci|comment|pourquoi)\b/i.test(normalized)) return "fr";
    if (/\b(hallo|danke|warum|bitte)\b/i.test(normalized)) return "de";

    return "unknown";
  }
}
