import type {
  KnowledgeItem,
  KnowledgeRetriever,
  SupportedLanguage,
} from "../core/types";

export class InMemoryKnowledgeRetriever implements KnowledgeRetriever {
  constructor(private readonly items: KnowledgeItem[] = []) {}

  async search(query: string, language: SupportedLanguage): Promise<KnowledgeItem[]> {
    const terms = query.toLocaleLowerCase().split(/\s+/).filter(Boolean);

    return this.items
      .filter((item) => item.language === language || item.language === "en")
      .map((item) => {
        const haystack = `${item.title} ${item.content}`.toLocaleLowerCase();
        const score = terms.reduce((sum, term) => sum + (haystack.includes(term) ? 1 : 0), 0);
        return { item, score };
      })
      .filter(({ score }) => score > 0)
      .sort((a, b) => b.score - a.score)
      .slice(0, 5)
      .map(({ item }) => item);
  }
}
