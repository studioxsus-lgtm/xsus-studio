# XSUS Studio / XSUS AI architecture

## Product boundary
- XSUS Studio: administration, knowledge curation, evaluation, configuration.
- XSUS AI: user-facing chat experience.
- XSUS API: authentication, authorization, request validation, rate limits, audit events.
- AI Core: shared orchestration contracts and request flow.
- Knowledge services: ingestion, retrieval, indexing, provenance.
- Model runtime: local/cloud model inference behind a stable interface.

## Request flow
Client -> authenticated API -> validation/security -> orchestrator -> language detection -> retrieval -> model runtime -> response checks -> client.

## Offline requirements
A working offline mode needs a local model runtime, model/tokenizer files, local knowledge and indexes, cached UI assets where appropriate, and no mandatory remote dependency in the offline path.

## Production checklist
- Real authentication and per-user authorization
- Input size limits and rate limiting
- Secrets stored outside source control
- Data retention and deletion policies
- Knowledge provenance and review workflow
- Unit, integration, security, and quality evaluations
- Logs that avoid storing sensitive content unnecessarily
