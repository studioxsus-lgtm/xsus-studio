# Knowledge ingestion

Future pipeline: upload/import -> parse -> normalize -> deduplicate -> source attribution -> validation -> evaluation -> publish.
Do not automatically promote arbitrary ingested content into trusted knowledge.
