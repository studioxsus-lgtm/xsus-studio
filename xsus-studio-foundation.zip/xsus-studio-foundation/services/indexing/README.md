# Knowledge indexing

Future indexing service for keyword search and semantic/vector search. Keep an index version linked to the knowledge dataset version.
