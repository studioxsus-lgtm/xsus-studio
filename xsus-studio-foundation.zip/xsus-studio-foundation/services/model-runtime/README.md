# Model runtime

This service will host or connect to a real model runtime (local or cloud).
Do not put model weights in Git. Store them in controlled artifact storage and document their license, checksum, and version.
Offline operation requires model files, tokenizer/configuration, dependencies, and runtime to be available locally.
