import { describe, expect, it } from "vitest";
import { AIOrchestrator } from "../src/ai/core/orchestrator";
import { BasicLanguageEngine } from "../src/ai/language/basic-language-engine";
import { InMemoryKnowledgeRetriever } from "../src/ai/retrieval/in-memory-retriever";
import { MockModelRuntime } from "../src/ai/responses/mock-model-runtime";

describe("AIOrchestrator", () => {
  it("rejects an empty message", async () => {
    const ai = new AIOrchestrator({
      language: new BasicLanguageEngine(),
      knowledge: new InMemoryKnowledgeRetriever(),
      model: new MockModelRuntime(),
    });

    await expect(ai.answer({ message: "   " })).rejects.toThrow("Mesazhi nuk mund të jetë bosh.");
  });

  it("returns a response for a non-empty message", async () => {
    const ai = new AIOrchestrator({
      language: new BasicLanguageEngine(),
      knowledge: new InMemoryKnowledgeRetriever(),
      model: new MockModelRuntime(),
    });

    const response = await ai.answer({ message: "Përshëndetje, çfarë është AI?" });
    expect(response.answer).toContain("XSUS AI");
    expect(response.language).toBe("sq");
  });
});
