# XSUS Studio app

Place or map the existing XSUS Studio admin/product UI here only if adopting a monorepo layout. Do not move existing app files until its framework and routes have been audited.
