# XSUS AI app

User-facing chat app. It should call the authenticated XSUS API and must never expose model-provider secrets to the browser.
