# Shared types

Place API request/response schemas and common contracts here when the web app and services need to share them.
