# Concepts

Store reviewed domain concepts here. Prefer source attribution, language metadata, versioning, and review status.
Do not treat unreviewed user input as trusted canonical knowledge.
