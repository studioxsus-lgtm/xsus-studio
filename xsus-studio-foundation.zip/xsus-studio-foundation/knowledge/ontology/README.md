# Ontology

Define stable concept IDs and relationships here. Keep concept identity separate from translations.
Suggested future fields: `id`, `labels`, `definition`, `broaderConcepts`, `relatedConcepts`, `sources`, `reviewStatus`.
