# XSUS Studio + XSUS AI Foundation

A modular starter foundation for the XSUS Studio platform and the XSUS AI application.

## Design
- `apps/studio`: reserved for the existing XSUS Studio UI.
- `apps/xsus-ai`: reserved for the XSUS AI chat UI.
- `src/ai`: shared AI orchestration and capability interfaces.
- `knowledge`: version-controlled starter knowledge and language packs.
- `services`: separate runtimes/workers that can be added when needed.
- `packages`: shared contracts used by both products.
- `tests`: unit and integration tests.

## Important
This is a starter scaffold, not a complete AI model or production-ready deployment.
It does not include model weights, secrets, database credentials, or cloud configuration.
Integrate it into the existing repository only after checking current paths and `package.json`.

## Suggested first steps
1. Review the existing repository and merge these folders rather than overwriting files.
2. Install Node.js and TypeScript in the project.
3. Implement an authenticated API route in the existing web framework.
4. Connect the orchestrator to a real model runtime and knowledge retrieval provider.
5. Add tests, logging, rate limiting, and access control before production.
