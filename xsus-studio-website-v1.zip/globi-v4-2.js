
// Uses the existing XSUS Studio Supabase client, without duplicating credentials.
import { supabase } from "./services/supabase-client.js";
const logoutButton=document.getElementById('xsusLogout');
const userLabel=document.getElementById('xsusUser');
const loginLink=document.querySelector('.actions a[data-t="login"]');
const signupLink=document.querySelector('.actions a[data-t="signup"]');
function updateAuthUI(session){
  const signedIn=Boolean(session?.user);
  if(loginLink)loginLink.hidden=signedIn;
  if(signupLink)signupLink.hidden=signedIn;
  if(logoutButton)logoutButton.hidden=!signedIn;
  if(userLabel){userLabel.hidden=!signedIn;userLabel.textContent=signedIn?(session.user.email||'XSUS account'):'';}
}
// CSS of the original V4 uses display rules; force hidden links to stay hidden.
const authHideStyle=document.createElement('style');
authHideStyle.textContent='.actions a[hidden]{display:none!important}';
document.head.appendChild(authHideStyle);
try{
  const {data,error}=await supabase.auth.getSession();
  if(error)throw error;
  updateAuthUI(data.session);
  supabase.auth.onAuthStateChange((_event,session)=>updateAuthUI(session));
}catch(error){console.warn('XSUS authentication status unavailable:',error);}
logoutButton?.addEventListener('click',async()=>{
  logoutButton.disabled=true;
  try{
    const {error}=await supabase.auth.signOut();
    if(error)throw error;
    updateAuthUI(null);
  }catch(error){console.error('XSUS logout failed:',error);alert('Could not log out. Please try again.');}
  finally{logoutButton.disabled=false;}
});
// Preserve V4 translations for the newly added button.
const authTranslations={en:'Logout',sq:'Dil',fr:'Déconnexion'};
function updateLogoutLanguage(){if(logoutButton)logoutButton.textContent=authTranslations[document.getElementById('language')?.value]||authTranslations.en;}
document.getElementById('language')?.addEventListener('change',updateLogoutLanguage);
updateLogoutLanguage();
